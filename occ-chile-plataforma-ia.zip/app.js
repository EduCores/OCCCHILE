/* =========================================================
   OCC Chile · Plataforma IA — app.js (vanilla, sin build)
   Estructura modular pensada para migrar a React/Next.js:
   cada bloque init*() ≈ un componente futuro.
   ========================================================= */
(() => {
  "use strict";

  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const icons = () => window.lucide && window.lucide.createIcons();
  const fmt = (n, d = 0) => Number(n).toLocaleString("es-CL", { minimumFractionDigits: d, maximumFractionDigits: d });
  const norm = (s) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9ñ\s]/g, " ").replace(/\s+/g, " ").trim();
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch { /* sin storage */ } },
  };
  let toastT;
  const toast = (msg, icon = "check-circle-2") => {
    const t = $("#toast");
    t.innerHTML = `<i data-lucide="${icon}"></i> ${msg}`;
    icons();
    t.classList.add("is-on");
    clearTimeout(toastT);
    toastT = setTimeout(() => t.classList.remove("is-on"), 3200);
  };

  /* ---------------- DATA ---------------- */
  const REGIONS = [
    { n: "Arica y Parinacota", s: "Arica", d: 92.1, b: 6120 },
    { n: "Tarapacá", s: "Tarapacá", d: 88.4, b: 7480 },
    { n: "Antofagasta", s: "Antofagasta", d: 76.2, b: 11950 },
    { n: "Atacama", s: "Atacama", d: 84.9, b: 5830 },
    { n: "Coquimbo", s: "Coquimbo", d: 93.5, b: 12400 },
    { n: "Valparaíso", s: "Valparaíso", d: 94.2, b: 24610 },
    { n: "Metropolitana", s: "Metropolitana", d: 95.8, b: 77120 },
    { n: "O'Higgins", s: "O'Higgins", d: 91.0, b: 10340 },
    { n: "Maule", s: "Maule", d: 89.7, b: 12880 },
    { n: "Ñuble", s: "Ñuble", d: 87.3, b: 5920 },
    { n: "Biobío", s: "Biobío", d: 92.6, b: 18450 },
    { n: "La Araucanía", s: "Araucanía", d: 86.1, b: 12940 },
    { n: "Los Ríos", s: "Los Ríos", d: 90.3, b: 5480 },
    { n: "Los Lagos", s: "Los Lagos", d: 85.5, b: 10260 },
    { n: "Aysén", s: "Aysén", d: 78.4, b: 1874 },
    { n: "Magallanes", s: "Magallanes", d: 81.0, b: 4370 },
  ];
  REGIONS.forEach((r, i) => (r.i = i));

  const PROCESSES = [
    { t: "Captación de iglesias", pain: "Email manual con 7 campos", sol: "Formulario inteligente + clasificación automática", imp: "alto", ic: "church", m: "A", e: 24, v: 94,
      b: ["Autocompletado de direcciones", "Clasificación por región/tamaño", "Deduplicación fuzzy"] },
    { t: "Onboarding de voluntarios", pain: "Manual, sin seguimiento", sol: "Chatbot + flujo automatizado + recordatorios", imp: "alto", ic: "user-plus", m: "B", e: 40, v: 76,
      b: ["Checklist por rol", "Matching por habilidades", "Alertas de inactividad"] },
    { t: "Reportes maestro / distribución", pain: "Google Forms gigantes en iframes", sol: "Formularios nativos + validación IA", imp: "alto", ic: "clipboard-check", m: "C", e: 46, v: 92,
      b: ["UX móvil por pasos", "Detección de inconsistencias", "Consolidación automática"] },
    { t: "Logística de cajas", pain: "Conteo y distribución manual", sol: "Visión por computador + OCR", imp: "medio-alto", ic: "package", m: "D", e: 82, v: 74,
      b: ["Conteo por cámaras", "OCR de etiquetas", "Rutas con OR-Tools"] },
    { t: "Métricas nacionales", pain: "Reporte manual en PPT", sol: "Dashboard con IA + alertas", imp: "alto", ic: "bar-chart-3", m: "E", e: 60, v: 84,
      b: ["KPIs en tiempo real", "Alertas < 80%", "Resúmenes ejecutivos"] },
    { t: "Capacitación", pain: "Solo eventos presenciales", sol: "Contenido IA (guías, videos, quiz)", imp: "medio", ic: "graduation-cap", m: "F", e: 45, v: 58,
      b: ["Guías por rol", "Quiz con feedback", "Actas automáticas"] },
    { t: "Comunicación", pain: "Redes gestionadas a mano", sol: "Generación de contenido + programación", imp: "medio", ic: "megaphone", m: "G", e: 25, v: 55,
      b: ["Calendario editorial", "Posts por hito", "Newsletter regional"] },
    { t: "Atención a consultas", pain: "Email lento", sol: "Chatbot RAG sobre FAQs/documentos", imp: "alto", ic: "message-circle-heart", m: "H", e: 31, v: 82,
      b: ["Respuestas citadas", "Enrutamiento por tema", "Sugerencias al equipo"] },
    { t: "Traducción / localización", pain: "Proceso manual", sol: "IA multilingüe", imp: "bajo-medio", ic: "languages", m: "F", e: 18, v: 32,
      b: ["Materiales ES/EN/PT", "Revisión humana", "Glosario de la obra"] },
  ];
  const IMP_LABEL = { alto: "Alto", "medio-alto": "Medio-Alto", medio: "Medio", "bajo-medio": "Bajo-Medio" };
  const IMP_COLOR = { alto: "var(--red)", "medio-alto": "#e5662b", medio: "#d49112", "bajo-medio": "var(--pine-2)" };

  const FLOWS = [
    { k: "A", t: "Captación y onboarding de iglesias", ic: "church",
      before: "La iglesia envía un email a contacto con 7 datos (nombre, contacto, dirección postal, dirección de distribución, niños por rango etario, email, celular). El equipo procesa todo a mano.",
      after: "Formulario guiado o chatbot que valida, clasifica y asigna la postulación al equipo regional en segundos.",
      items: ["Formulario web con validación en tiempo real", "Autocompletado de direcciones (Google Maps API)", "Clasificación IA por región, tamaño y urgencia", "Chatbot en “¿Quieres ser parte?”", "Deduplicación por similitud de nombre/dirección", "Respuesta automática con próximos pasos y materiales"],
      kpi: [["Tiempo de respuesta", "Días → minutos"], ["Conversión", "↑ postulaciones completas"]] },
    { k: "B", t: "Onboarding y gestión de voluntarios", ic: "users",
      before: "27 voluntarios nuevos y equipos regionales de 6 roles coordinados por email y redes, sin seguimiento.",
      after: "Asistente que acompaña a cada voluntario según su rol y alerta cuando alguien se desconecta.",
      items: ["Checklist, manuales y capacitaciones por rol", "Matching de voluntarios a roles por habilidades/ubicación", "Recordatorios automáticos de tareas", "Análisis de engagement con alertas proactivas", "Certificados y badges personalizados"],
      kpi: [["Activación", "Onboarding en 7 días"], ["Retención", "↓ voluntarios inactivos"]] },
    { k: "C", t: "Reportes post-distribución y del maestro", ic: "clipboard-check",
      before: "Google Forms embebidos con iframes enormes, llenado manual y consolidación en planillas.",
      after: "Formularios nativos móviles que validan, leen fotos de evidencia y consolidan solos.",
      items: ["Formularios nativos con UX móvil", "Validación inteligente de inconsistencias y rangos", "OCR + visión sobre fotos de evidencia", "Detección de anomalías (duplicados, cajas no distribuidas)", "Resumen ejecutivo automático por región"],
      kpi: [["Errores", "↓ 70% datos inválidos"], ["Consolidación", "Manual → automática"]] },
    { k: "D", t: "Logística y distribución de cajitas", ic: "truck",
      before: "Recepción, conteo y distribución manual de 228.024 cajas, con meta de 42 contenedores en 2027.",
      after: "Cada caja contada y trazada por cámara, con rutas y stock optimizados por región.",
      items: ["Conteo automático por visión en bodegas", "Optimización de rutas (OR-Tools + IA)", "Predicción de demanda regional", "Inventario con alertas de stock", "OCR de etiquetas para trazabilidad"],
      kpi: [["Exactitud de conteo", "> 99%"], ["Kilómetros", "↓ 15–25%"]] },
    { k: "E", t: "Métricas, monitoreo y decisiones", ic: "layout-dashboard",
      before: "Métricas presentadas en PPT manual (228k cajas, 90,5% distribuidas…).",
      after: "Dashboard vivo con alertas y reportes ejecutivos que se escriben solos.",
      items: ["KPIs nacionales y regionales en tiempo real", "Alertas cuando una región baja de 80%", "Predicción de cumplimiento de 42 contenedores", "Reportes ejecutivos mensuales/trimestrales con IA", "Análisis de sentimiento de feedback"],
      kpi: [["Visibilidad", "Semanal → tiempo real"], ["Preparación de reportes", "Horas → segundos"]] },
    { k: "F", t: "Capacitación y discipulado", ic: "graduation-cap",
      before: "Eventos presenciales (V Región 105, Metropolitana 190 asistentes) y materiales estáticos.",
      after: "Aprendizaje continuo por rol, disponible 24/7 y en varios idiomas.",
      items: ["Guías de capacitación por rol (IA + revisión humana)", "Chatbot de soporte operativo", "Quiz y evaluación con retroalimentación", "Traducción automática de materiales", "Transcripción y resumen de reuniones"],
      kpi: [["Alcance", "Capacitación sin límite de aforo"], ["Actas", "Automáticas"]] },
    { k: "G", t: "Comunicación y marketing digital", ic: "megaphone",
      before: "Facebook/Instagram y web con contenido manual, sin calendario editorial.",
      after: "Calendario editorial asistido por IA, alineado a los hitos de cada región.",
      items: ["Posts, historias y guiones de reels por hito (Calama, Punta Arenas, Puerto Natales)", "Programación automática (Buffer/Hootsuite)", "Respuestas a DMs/comentarios frecuentes", "Newsletter personalizado por región", "SEO: noindex, páginas demo, velocidad"],
      kpi: [["Frecuencia", "Publicación constante"], ["Alcance orgánico", "↑ con SEO técnico"]] },
    { k: "H", t: "Atención y soporte", ic: "life-buoy",
      before: "Formulario Contact Form 7 + email; respuesta manual y lenta.",
      after: "Asistente RAG que responde con fuentes y deriva al equipo correcto.",
      items: ["Chatbot RAG con FAQs, manuales y páginas del sitio", "Clasificación y enrutamiento (voluntariado, donaciones, iglesias, prensa)", "Respuestas sugeridas para el equipo", "Análisis de temas recurrentes"],
      kpi: [["Primera respuesta", "< 5 segundos"], ["Consultas resueltas", "~70% sin intervención"]] },
  ];

  /* ---------------- THEME ---------------- */
  function initTheme() {
    const root = document.documentElement;
    const saved = store.get("occ-theme");
    if (saved) root.dataset.theme = saved;
    const isDark = () => root.dataset.theme ? root.dataset.theme === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
    const paint = () => { $("#themeToggle").innerHTML = `<i data-lucide="${isDark() ? "sun" : "moon"}"></i>`; icons(); };
    $("#themeToggle").addEventListener("click", () => {
      root.dataset.theme = isDark() ? "light" : "dark";
      store.set("occ-theme", root.dataset.theme);
      paint();
    });
    paint();
  }

  /* ---------------- NAV / SCROLL ---------------- */
  function initNav() {
    const nav = $("#nav"), bar = $("#progress"), links = $$("#navLinks a");
    const onScroll = () => {
      const y = scrollY, h = document.documentElement.scrollHeight - innerHeight;
      nav.classList.toggle("is-scrolled", y > 20);
      bar.style.width = (y / h) * 100 + "%";
    };
    addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    $("#burger").addEventListener("click", () => $("#navLinks").classList.toggle("is-open"));
    links.forEach((a) => a.addEventListener("click", () => $("#navLinks").classList.remove("is-open")));
    const io = new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting) links.forEach((a) => a.classList.toggle("is-active", a.getAttribute("href") === "#" + e.target.id));
    }), { rootMargin: "-45% 0px -50% 0px" });
    ["procesos", "flujos", "demos", "arquitectura", "roadmap"].forEach((id) => io.observe(document.getElementById(id)));
  }

  function initReveal() {
    const io = new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add("is-in"); io.unobserve(e.target); }
    }), { threshold: 0.12 });
    $$(".reveal").forEach((el, i) => { el.style.transitionDelay = (i % 5) * 70 + "ms"; io.observe(el); });
  }

  function animateCount(el, to, dec = 0, suffix = "", dur = 1800) {
    const t0 = performance.now();
    const step = (t) => {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 4);
      el.textContent = fmt(to * e, dec) + suffix;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
  function initCounters() {
    const io = new IntersectionObserver((es) => es.forEach((e) => {
      if (!e.isIntersecting) return;
      const el = e.target;
      animateCount(el, parseFloat(el.dataset.count), +(el.dataset.decimals || 0), el.dataset.suffix || "");
      io.unobserve(el);
    }), { threshold: 0.5 });
    $$("[data-count]").forEach((el) => io.observe(el));
  }

  /* ---------------- HERO ---------------- */
  function initHero() {
    const gift = $("#gift");
    gift.addEventListener("click", () => {
      gift.classList.remove("is-open");
      void gift.offsetWidth;
      gift.classList.add("is-open");
      toast("¡Una cajita más camino a un niño! 🎁", "gift");
      setTimeout(() => gift.classList.remove("is-open"), 2600);
    });
    const scan = $('[data-live="scan"]');
    let n = 1284;
    setInterval(() => { n += Math.ceil(Math.random() * 3); scan.textContent = fmt(n); }, 1800);

    // partículas (nieve dorada/roja suave)
    const c = $("#snow"), ctx = c.getContext("2d");
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let W, H, parts = [];
    const resize = () => { W = c.width = c.offsetWidth * devicePixelRatio; H = c.height = c.offsetHeight * devicePixelRatio; };
    resize(); addEventListener("resize", resize);
    const cols = ["rgba(242,179,61,", "rgba(214,31,60,", "rgba(26,107,82,"];
    for (let i = 0; i < 60; i++) parts.push({ x: Math.random(), y: Math.random(), r: Math.random() * 2.4 + .6, s: Math.random() * .0006 + .0002, w: Math.random() * 6.28, c: cols[i % 3], a: Math.random() * .5 + .2 });
    let visible = true;
    new IntersectionObserver(([e]) => (visible = e.isIntersecting)).observe(c);
    (function loop() {
      if (visible) {
        ctx.clearRect(0, 0, W, H);
        parts.forEach((p) => {
          p.y += p.s; p.w += .01;
          if (p.y > 1.02) { p.y = -.02; p.x = Math.random(); }
          ctx.beginPath();
          ctx.arc((p.x + Math.sin(p.w) * .01) * W, p.y * H, p.r * devicePixelRatio, 0, 6.28);
          ctx.fillStyle = p.c + p.a + ")";
          ctx.fill();
        });
      }
      requestAnimationFrame(loop);
    })();
  }

  /* ---------------- PROCESS MAP ---------------- */
  function initProcesses() {
    const grid = $("#processGrid");
    grid.innerHTML = PROCESSES.map((p, i) => `
      <article class="pcard reveal" data-imp="${p.imp}" tabindex="0" aria-label="${p.t}">
        <div class="pcard__inner">
          <div class="pcard__face pcard__face--front">
            <span class="pcard__num">${String(i + 1).padStart(2, "0")}</span>
            <div class="pcard__icon"><i data-lucide="${p.ic}"></i></div>
            <h3>${p.t}</h3>
            <p class="pain"><i data-lucide="circle-alert"></i> ${p.pain}</p>
            <div class="pcard__foot"><span class="impact impact--${p.imp}">${IMP_LABEL[p.imp]}</span><span>Ver solución <i data-lucide="rotate-cw"></i></span></div>
          </div>
          <div class="pcard__face pcard__face--back">
            <h4>Solución IA · Módulo ${p.m}</h4>
            <p>${p.sol}</p>
            <ul>${p.b.map((x) => `<li>${x}</li>`).join("")}</ul>
            <div class="pcard__foot"><span>Impacto ${IMP_LABEL[p.imp]}</span><span>Volver <i data-lucide="rotate-ccw"></i></span></div>
          </div>
        </div>
      </article>`).join("");
    $$(".pcard", grid).forEach((c) => {
      const flip = () => c.classList.toggle("is-flipped");
      c.addEventListener("click", flip);
      c.addEventListener("keydown", (e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), flip()));
    });
    $$("#impactFilters .chip").forEach((b) => b.addEventListener("click", () => {
      $$("#impactFilters .chip").forEach((x) => x.classList.toggle("is-active", x === b));
      const f = b.dataset.filter;
      $$(".pcard", grid).forEach((c) => c.classList.toggle("is-hidden", f !== "all" && c.dataset.imp !== f));
    }));

    const m = $("#matrix");
    PROCESSES.forEach((p, i) => {
      const d = document.createElement("span");
      d.className = "mdot";
      d.textContent = String(i + 1).padStart(2, "0");
      d.title = `${p.t} — ${p.sol}`;
      d.style.left = 6 + p.e * .88 + "%";
      d.style.bottom = 4 + p.v * .86 + "%";
      d.style.background = IMP_COLOR[p.imp];
      d.style.transitionDelay = i * 80 + "ms";
      m.appendChild(d);
    });
    const legend = document.createElement("ol");
    legend.className = "matrix__legend";
    legend.innerHTML = PROCESSES.map((p, i) => `<li><b style="background:${IMP_COLOR[p.imp]}">${String(i + 1).padStart(2, "0")}</b>${p.t}</li>`).join("");
    m.after(legend);
    new IntersectionObserver(([e], o) => { if (e.isIntersecting) { m.classList.add("is-in"); o.disconnect(); } }, { threshold: .3 }).observe(m);
  }

  /* ---------------- FLOWS ---------------- */
  function initFlows() {
    const tabs = $("#flowTabs"), panel = $("#flowPanel");
    tabs.innerHTML = FLOWS.map((f, i) => `<button class="ftab${i ? "" : " is-active"}" role="tab" data-i="${i}"><b>${f.k}</b><span>${f.t}</span></button>`).join("");
    const render = (i) => {
      const f = FLOWS[i];
      panel.classList.remove("swap"); void panel.offsetWidth; panel.classList.add("swap");
      panel.innerHTML = `
        <div class="fp__top"><div class="big"><i data-lucide="${f.ic}"></i></div><div><small>Flujo ${f.k}</small><h3>${f.t}</h3></div></div>
        <div class="compare">
          <div class="compare__col compare__col--before"><h5><i data-lucide="hourglass"></i> Flujo actual</h5><p>${f.before}</p></div>
          <div class="compare__arrow"><i data-lucide="arrow-right"></i></div>
          <div class="compare__col compare__col--after"><h5><i data-lucide="sparkles"></i> Con IA</h5><p>${f.after}</p></div>
        </div>
        <ul class="fp__list">${f.items.map((x, j) => `<li style="animation-delay:${j * 70}ms"><i data-lucide="check"></i><span>${x}</span></li>`).join("")}</ul>
        <div class="fp__kpi">${f.kpi.map(([a, b]) => `<div><small>KPI · ${a}</small><strong>${b}</strong></div>`).join("")}</div>`;
      icons();
    };
    tabs.addEventListener("click", (e) => {
      const b = e.target.closest(".ftab"); if (!b) return;
      $$(".ftab", tabs).forEach((x) => x.classList.toggle("is-active", x === b));
      render(+b.dataset.i);
      b.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
    });
    render(0);
  }

  /* ---------------- DEMO TABS ---------------- */
  const demoHooks = {};
  function initDemoTabs() {
    $("#demoTabs").addEventListener("click", (e) => {
      const b = e.target.closest(".demo-tab"); if (!b) return;
      $$(".demo-tab").forEach((x) => x.classList.toggle("is-active", x === b));
      $$(".demo").forEach((d) => d.classList.toggle("is-active", d.id === "demo-" + b.dataset.demo));
      demoHooks[b.dataset.demo] && demoHooks[b.dataset.demo]();
    });
  }
  const isDemoOn = (k) => $("#demo-" + k).classList.contains("is-active") && !document.hidden;

  /* ---------------- A · SMART FORM ---------------- */
  const ADDRESSES = [
    { a: "Av. Granaderos 2050, Calama", r: "Antofagasta" },
    { a: "Av. Argentina 1340, Antofagasta", r: "Antofagasta" },
    { a: "Av. Brasil 2241, Valparaíso", r: "Valparaíso" },
    { a: "Calle Valparaíso 650, Viña del Mar", r: "Valparaíso" },
    { a: "Av. Vicuña Mackenna 4860, Macul, Santiago", r: "Metropolitana" },
    { a: "Gran Avenida 5420, San Miguel, Santiago", r: "Metropolitana" },
    { a: "Av. Colón 1110, Talcahuano", r: "Biobío" },
    { a: "O'Higgins 940, Concepción", r: "Biobío" },
    { a: "Av. Alemania 0280, Temuco", r: "La Araucanía" },
    { a: "Av. Bulnes 0910, Punta Arenas", r: "Magallanes" },
    { a: "Baquedano 255, Puerto Natales", r: "Magallanes" },
    { a: "21 de Mayo 380, Arica", r: "Arica y Parinacota" },
    { a: "Av. Ejército 1120, Coyhaique", r: "Aysén" },
    { a: "Av. Francisco del Campo 470, La Serena", r: "Coquimbo" },
    { a: "Av. Angelmó 2350, Puerto Montt", r: "Los Lagos" },
    { a: "Picarte 1450, Valdivia", r: "Los Ríos" },
    { a: "1 Sur 1290, Talca", r: "Maule" },
    { a: "Av. Libertad 410, Chillán", r: "Ñuble" },
    { a: "Av. Copayapu 2100, Copiapó", r: "Atacama" },
    { a: "Av. Arturo Prat 2120, Iquique", r: "Tarapacá" },
    { a: "Av. Libertador B. O'Higgins 640, Rancagua", r: "O'Higgins" },
  ];
  const EXISTING = [
    { n: "Iglesia Evangélica Luz del Valle", c: "Calama" },
    { n: "Iglesia Bautista Getsemaní", c: "Temuco" },
    { n: "Comunidad Cristiana Esperanza", c: "Calama" },
    { n: "Iglesia Metodista Pentecostal Jotabeche", c: "Santiago" },
    { n: "Centro Cristiano Vida Nueva", c: "Punta Arenas" },
    { n: "Iglesia Alianza Cristiana y Misionera El Faro", c: "Valparaíso" },
    { n: "Ministerio Restauración Familiar", c: "Concepción" },
    { n: "Iglesia Presbiteriana San Pablo", c: "Puerto Montt" },
  ];
  const STOP = new Set(["iglesia", "evangelica", "comunidad", "cristiana", "ministerio", "centro", "de", "del", "la", "el", "los", "las", "y"]);
  function lev(a, b) {
    const m = a.length, n = b.length; if (!m || !n) return Math.max(m, n);
    let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[n];
  }
  function similarity(a, b) {
    const core = (s) => norm(s).split(" ").filter((w) => !STOP.has(w)).join(" ");
    const x = core(a), y = core(b);
    if (!x || !y) return 0;
    const ed = 1 - lev(x, y) / Math.max(x.length, y.length);
    const tx = new Set(x.split(" ")), ty = new Set(y.split(" "));
    const jac = [...tx].filter((t) => ty.has(t)).length / new Set([...tx, ...ty]).size;
    return Math.max(ed, jac * .95);
  }

  function initForm() {
    const f = $("#churchForm");
    const F = { name: $("#fName"), contact: $("#fContact"), email: $("#fEmail"), phone: $("#fPhone"), addr: $("#fAddr") };
    let step = 0, region = null, submitted = false;
    const rules = {
      name: (v) => v.trim().length >= 4 || "Mínimo 4 caracteres",
      contact: (v) => v.trim().split(/\s+/).length >= 2 || "Incluye nombre y apellido",
      email: (v) => /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(v.trim()) || "Email no válido",
      phone: (v) => { const d = v.replace(/\D/g, "").replace(/^56/, ""); return /^9\d{8}$/.test(d) || "Formato: +56 9 XXXX XXXX"; },
      addr: (v) => v.trim().length >= 8 || "Selecciona o escribe una dirección",
    };
    const okMsg = { name: "✓ Nombre válido", contact: "✓ Perfecto", email: "✓ Email válido", phone: "✓ Celular chileno válido", addr: "✓ Dirección verificada" };
    const check = (k, show = true) => {
      const r = rules[k](F[k].value), ok = r === true, h = $(`.hint[data-for="${F[k].id}"]`);
      if (show && F[k].value) {
        F[k].classList.toggle("ok", ok); F[k].classList.toggle("err", !ok);
        h.textContent = ok ? okMsg[k] : r; h.className = "hint " + (ok ? "ok" : "err");
      }
      return ok;
    };
    Object.keys(F).forEach((k) => {
      F[k].addEventListener("input", () => { F[k].classList.remove("err"); if (k !== "addr") check(k); update(); });
      F[k].addEventListener("blur", () => { check(k); update(); });
    });
    F.phone.addEventListener("blur", () => {
      const d = F.phone.value.replace(/\D/g, "").replace(/^56/, "");
      if (/^9\d{8}$/.test(d)) F.phone.value = `+56 ${d[0]} ${d.slice(1, 5)} ${d.slice(5)}`;
    });

    // autocompletado
    const ac = $("#acList"); let hl = -1, opts = [];
    const pick = (o) => { F.addr.value = o.a; region = o.r; ac.classList.remove("is-open"); check("addr"); update(); };
    F.addr.addEventListener("input", () => {
      region = null;
      const q = norm(F.addr.value);
      opts = q.length < 2 ? [] : ADDRESSES.filter((o) => norm(o.a + " " + o.r).includes(q)).slice(0, 5);
      hl = -1;
      ac.innerHTML = opts.map((o, i) => `<li data-i="${i}" role="option"><i data-lucide="map-pin"></i>${o.a}<small>${o.r}</small></li>`).join("");
      ac.classList.toggle("is-open", opts.length > 0); icons();
      // detección de región por texto libre
      const hit = ADDRESSES.find((o) => q && norm(o.a).split(",").pop().trim() && q.includes(norm(o.a.split(",").pop())));
      if (hit) region = hit.r;
      update();
    });
    F.addr.addEventListener("keydown", (e) => {
      if (!ac.classList.contains("is-open")) return;
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault(); hl = (hl + (e.key === "ArrowDown" ? 1 : -1) + opts.length) % opts.length;
        $$("li", ac).forEach((li, i) => li.classList.toggle("is-hl", i === hl));
      } else if (e.key === "Enter" && hl >= 0) { e.preventDefault(); pick(opts[hl]); }
      else if (e.key === "Escape") ac.classList.remove("is-open");
    });
    ac.addEventListener("mousedown", (e) => { const li = e.target.closest("li"); if (li) { e.preventDefault(); pick(opts[+li.dataset.i]); } });
    F.addr.addEventListener("blur", () => setTimeout(() => ac.classList.remove("is-open"), 120));
    $("#sameAddr").addEventListener("change", (e) => ($("#distField").hidden = e.target.checked));

    // niños
    const kids = () => ["k1", "k2", "k3"].map((id) => Math.max(0, parseInt($("#" + id).value) || 0));
    $$(".stepper button").forEach((b) => b.addEventListener("click", () => {
      const i = $("#" + b.dataset.k); i.value = Math.max(0, (parseInt(i.value) || 0) + +b.dataset.d); update();
    }));
    $$(".stepper input").forEach((i) => i.addEventListener("input", update));

    function setDD(id, val) { const el = $(id); if (el.textContent !== val) { el.textContent = val; el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash"); } }

    function update() {
      const k = kids(), total = k.reduce((a, b) => a + b, 0);
      animateCount($("#kidsTotal"), total, 0, "", 300);
      const kh = $("#kidsHint");
      if (total > 600) { kh.textContent = "⚠ Cantidad inusual para una sola iglesia: un coordinador lo confirmará."; kh.className = "hint err"; }
      else if (total && k[1] === 0) { kh.textContent = "ℹ El rango 5–9 suele ser el mayor. ¿Es correcto en 0?"; kh.className = "hint"; }
      else { kh.textContent = ""; kh.className = "hint"; }

      setDD("#cRegion", region || "—");
      setDD("#cSize", !total ? "—" : total < 50 ? `Pequeña · ${total}` : total < 150 ? `Mediana · ${total}` : `Grande · ${total}`);
      const remote = ["Magallanes", "Aysén", "Arica y Parinacota", "Antofagasta", "Tarapacá"].includes(region);
      const regionPct = region ? (REGIONS.find((r) => r.n === region) || {}).d : null;
      let urg = "—";
      if (region || total) urg = remote || total >= 200 || (regionPct && regionPct < 80) ? "🔴 Alta" : total >= 80 ? "🟠 Media" : "🟢 Normal";
      setDD("#cUrg", urg);
      setDD("#cTeam", region ? `Equipo ${REGIONS.find((r) => r.n === region)?.s || region}` : "—");

      // dedup
      const name = F.name.value;
      const dd = $("#dedup");
      if (name.trim().length < 4) dd.innerHTML = `<p class="muted">Escribe el nombre de la iglesia…</p>`;
      else {
        const hits = EXISTING.map((x) => ({ ...x, s: similarity(name, x.n) })).filter((x) => x.s > .5).sort((a, b) => b.s - a.s).slice(0, 2);
        dd.innerHTML = hits.length
          ? hits.map((h) => `<div class="match ${h.s > .8 ? "high" : "mid"}"><i data-lucide="${h.s > .8 ? "copy" : "git-compare"}"></i><div><strong>${h.n}</strong><br><small class="muted">${h.c} · ${h.s > .8 ? "posible duplicado" : "similar"}</small></div><span class="sim">${Math.round(h.s * 100)}%</span></div>`).join("")
          : `<div class="match"><i data-lucide="badge-check"></i> Sin duplicados en la base <span class="sim" style="color:var(--ok)">Nueva</span></div>`;
        icons();
      }

      const checks = [...Object.keys(F).map((k) => rules[k](F[k].value) === true), total > 0];
      const q = Math.round((checks.filter(Boolean).length / checks.length) * 100);
      $("#qBar").style.width = q + "%";
      $("#qBar").style.backgroundPosition = 100 - q + "% 0";
      $("#qPct").textContent = q + "%";
    }

    // pasos
    const stepFields = [["name", "contact", "email", "phone"], ["addr"], []];
    const go = (n) => {
      step = n;
      $$(".fstep", f).forEach((s) => s.classList.toggle("is-active", +s.dataset.step === n));
      $$("#formSteps span").forEach((s, i) => s.classList.toggle("is-on", i <= n));
      $("#prevStep").disabled = n === 0;
      $("#nextStep").innerHTML = n === 2 ? `<i data-lucide="send"></i> Enviar postulación` : `Siguiente <i data-lucide="arrow-right"></i>`;
      icons();
    };
    $("#prevStep").addEventListener("click", () => go(Math.max(0, step - 1)));
    $("#nextStep").addEventListener("click", () => {
      const bad = stepFields[step].filter((k) => !check(k));
      if (bad.length) {
        bad.forEach((k) => { F[k].classList.add("err"); const h = $(`.hint[data-for="${F[k].id}"]`); if (!F[k].value) { h.textContent = "Campo requerido"; h.className = "hint err"; } });
        F[bad[0]].focus(); return;
      }
      if (step < 2) return go(step + 1);
      if (!kids().reduce((a, b) => a + b, 0)) { $("#kidsHint").textContent = "Indica al menos un niño."; $("#kidsHint").className = "hint err"; return; }
      submit();
    });
    function submit() {
      if (submitted) return;
      submitted = true;
      const r = $("#autoReply");
      const total = kids().reduce((a, b) => a + b, 0);
      const first = F.contact.value.trim().split(" ")[0];
      r.hidden = false;
      r.innerHTML = `<h4><i data-lucide="mail-check"></i> Respuesta automática generada</h4>
        <p>Hola ${first}, ¡gracias por sumar a <b>${F.name.value.trim()}</b>! 🎁</p>
        <p>Tu postulación para <b>${fmt(total)} niños</b> fue asignada al <b>${$("#cTeam").textContent}</b>. En las próximas 48 h te contactarán para coordinar la entrega.</p>
        <p><b>Próximos pasos:</b> 1) Ver video de bienvenida · 2) Descargar guía de distribución · 3) Agendar capacitación de El Gran Viaje.</p>`;
      icons();
      toast("Postulación clasificada y asignada en 0,8 s");
      $("#nextStep").innerHTML = `<i data-lucide="check"></i> Enviada`; $("#nextStep").disabled = true; icons();
    }
    $("#fillDemo").addEventListener("click", async () => {
      const typeIn = async (el, txt) => { el.value = ""; for (const ch of txt) { el.value += ch; el.dispatchEvent(new Event("input")); await sleep(14); } el.dispatchEvent(new Event("blur")); };
      go(0);
      await typeIn(F.name, "Comunidad Cristiana La Esperanza");
      await typeIn(F.contact, "Marcela Rojas Fuentes");
      await typeIn(F.email, "contacto@laesperanza.cl");
      await typeIn(F.phone, "987654321");
      await sleep(250); go(1);
      await typeIn(F.addr, "Granaderos");
      await sleep(400); pick(ADDRESSES[0]);
      await sleep(350); go(2);
      $("#k1").value = 45; $("#k2").value = 92; $("#k3").value = 60; update();
    });
    go(0); update();
  }

  /* ---------------- B · VOLUNTARIOS ---------------- */
  const SKILLS = ["Conducción", "Logística", "Redes sociales", "Enseñanza", "Diseño", "Excel / datos", "Liderazgo", "Fotografía", "Oración", "Inglés", "Relación con iglesias"];
  const ROLES = [
    { n: "Coordinador/a regional", ic: "crown", s: { Liderazgo: 3, "Relación con iglesias": 2, Oración: 1, Logística: 1 }, h: 10,
      cl: ["Reunión 1:1 con coordinación nacional", "Manual del coordinador regional", "Acceso al dashboard regional", "Plan de metas de cajas"] },
    { n: "Relación con iglesias", ic: "church", s: { "Relación con iglesias": 3, Oración: 2, Enseñanza: 1, Liderazgo: 1 }, h: 5,
      cl: ["Guía de captación de iglesias", "Guion de visita pastoral", "Acceso al CRM de iglesias", "Capacitación El Gran Viaje"] },
    { n: "Logística y bodega", ic: "truck", s: { Logística: 3, Conducción: 3, "Excel / datos": 1 }, h: 6,
      cl: ["Protocolo de bodega y seguridad", "App de conteo con cámara", "Mapa de rutas de su región", "Turnos de semana de recolección"] },
    { n: "Comunicaciones", ic: "megaphone", s: { "Redes sociales": 3, Fotografía: 2, Diseño: 2, Inglés: 1 }, h: 4,
      cl: ["Manual de marca y tono", "Banco de fotos con consentimiento", "Calendario editorial IA", "Plantillas de historias"] },
    { n: "Capacitación / El Gran Viaje", ic: "graduation-cap", s: { Enseñanza: 3, Oración: 2, Liderazgo: 1, Inglés: 1 }, h: 5,
      cl: ["Curso de facilitador (online)", "Quiz de certificación", "Materiales para maestros", "Reporte del maestro (formulario nativo)"] },
    { n: "Reportes y datos", ic: "database", s: { "Excel / datos": 3, Logística: 1, Diseño: 1 }, h: 3,
      cl: ["Tour del dashboard", "Guía de validación de reportes", "Alertas de anomalías", "Plantilla de resumen mensual"] },
  ];
  const VOLS = [
    ["Camila S.", "Valparaíso", 2, "#d61f3c"], ["Joaquín P.", "Biobío", 9, "#1a6b52"], ["Fernanda M.", "Metropolitana", 1, "#e5662b"],
    ["Diego A.", "Antofagasta", 23, "#2f6fdb"], ["Valentina R.", "Magallanes", 5, "#a855f7"], ["Matías C.", "Araucanía", 16, "#0f4d3a"],
    ["Ignacia T.", "Coquimbo", 3, "#b3122e"], ["Benjamín L.", "Los Lagos", 31, "#d49112"],
  ];
  function initVolunteers() {
    const sel = $("#vRegion");
    sel.innerHTML = REGIONS.map((r) => `<option ${r.n === "Valparaíso" ? "selected" : ""}>${r.n}</option>`).join("");
    const on = new Set(["Logística", "Conducción"]);
    $("#skills").innerHTML = SKILLS.map((s) => `<button type="button" class="skill${on.has(s) ? " is-on" : ""}">${s}</button>`).join("");
    $("#skills").addEventListener("click", (e) => {
      const b = e.target.closest(".skill"); if (!b) return;
      b.classList.toggle("is-on"); on.has(b.textContent) ? on.delete(b.textContent) : on.add(b.textContent); render();
    });
    sel.addEventListener("change", render);
    $("#vHours").addEventListener("input", (e) => { $("#vHoursOut").textContent = e.target.value; render(); });

    function render() {
      const hrs = +$("#vHours").value;
      const reg = REGIONS.find((r) => r.n === sel.value);
      const scored = ROLES.map((r) => {
        const max = Object.values(r.s).reduce((a, b) => a + b, 0);
        const got = Object.entries(r.s).reduce((a, [k, w]) => a + (on.has(k) ? w : 0), 0);
        let sc = (got / max) * 75 + Math.min(1, hrs / r.h) * 20;
        if (reg.d < 85 && r.n.startsWith("Logística")) sc += 5; // región con brecha de distribución
        return { ...r, sc: Math.min(99, Math.round(sc)) };
      }).sort((a, b) => b.sc - a.sc);
      $("#matches").innerHTML = scored.slice(0, 3).map((r, i) => `
        <li style="animation-delay:${i * 80}ms"><span class="ico"><i data-lucide="${r.ic}"></i></span>
          <div><strong>${r.n}</strong><small>${i === 0 ? `Mejor ajuste en ${reg.s}` : `${r.h} h/sem sugeridas`}${reg.d < 85 && r.n.startsWith("Logística") ? " · región prioritaria" : ""}</small>
          <div class="score-bar"><i style="width:${r.sc}%"></i></div></div>
          <span class="score">${r.sc}%</span></li>`).join("");
      const done = new Set();
      $("#checklist").innerHTML = scored[0].cl.map((c) => `<li><span class="cb"><i data-lucide="check" style="width:14px;height:14px"></i></span><span>${c}</span></li>`).join("");
      $$("#checklist li").forEach((li, i) => li.addEventListener("click", () => {
        li.classList.toggle("done"); done.has(i) ? done.delete(i) : done.add(i);
        if (done.size === scored[0].cl.length) toast("¡Onboarding completo! Badge “Mensajero de esperanza” desbloqueado 🏅", "award");
      }));
      icons();
    }
    $("#engage").innerHTML = VOLS.map(([n, r, d, c]) => {
      const st = d > 20 ? "inactive" : d > 7 ? "risk" : "";
      const col = d > 20 ? "var(--bad)" : d > 7 ? "var(--warn)" : "var(--ok)";
      return `<div class="vol ${st}"><span class="av" style="background:${c}">${n.split(" ").map((x) => x[0]).join("")}</span>
        <div><strong>${n}</strong><small>${r} · ${d === 1 ? "activo hoy" : `hace ${d} días`}</small>${st ? `<br><button data-n="${n}">Enviar recordatorio</button>` : ""}</div>
        <span class="st" style="background:${col}"></span></div>`;
    }).join("");
    $("#engage").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      b.textContent = "✓ Enviado"; b.disabled = true; b.style.background = "var(--ok)";
      toast(`Recordatorio personalizado enviado a ${b.dataset.n} por WhatsApp`, "send");
    });
    render();
  }

  /* ---------------- C · OCR ---------------- */
  function initOCR() {
    const stage = $("#ocrStage"), boxes = $("#ocrBoxes"), tbl = $("#ocrTable tbody"), flags = $("#ocrFlags");
    let busy = false, userImg = false;
    const FIELDS = [
      ["Iglesia", "Comunidad Cristiana Esperanza", 97], ["Ciudad", "Calama → Antofagasta", 99], ["Fecha", "14-12-2026", 95],
      ["Niños asistentes", "184", 93], ["Cajas entregadas", "197", 91], ["Inscritos El Gran Viaje", "63", 88], ["Firma", "Detectada (M. Rojas)", 84],
    ];
    async function run() {
      if (busy) return; busy = true;
      boxes.innerHTML = ""; flags.innerHTML = "";
      tbl.innerHTML = `<tr><td colspan="3" class="muted">Analizando imagen…</td></tr>`;
      stage.classList.add("is-scanning");
      await sleep(1600);
      if (!userImg) {
        const sr = stage.getBoundingClientRect();
        $$(".doc__row em", stage).forEach((em, i) => {
          const r = em.getBoundingClientRect();
          const b = document.createElement("i");
          Object.assign(b.style, { left: r.left - sr.left - 4 + "px", top: r.top - sr.top - 3 + "px", width: r.width + 8 + "px", height: r.height + 6 + "px", animationDelay: i * 90 + "ms" });
          boxes.appendChild(b);
        });
      }
      await sleep(1800);
      stage.classList.remove("is-scanning");
      tbl.innerHTML = FIELDS.map(([k, v, c], i) => `<tr style="animation-delay:${i * 70}ms"><td>${k}</td><td>${v}</td><td><span class="conf"><i style="--w:${c}%"></i>${c}%</span></td></tr>`).join("");
      await sleep(400);
      flags.innerHTML = [
        ["warn", "triangle-alert", "<b>Inconsistencia:</b> 197 cajas vs 184 niños (+13). ¿Hermanos ausentes o cajas de reserva? Se pidió confirmación al responsable."],
        ["ok", "copy-check", "<b>Sin duplicados:</b> no existe otro reporte de esta iglesia para el 14-12-2026."],
        ["ok", "map-pinned", "<b>Coherente:</b> Calama pertenece al Equipo Antofagasta (región en alerta: 76,2%)."],
        ["info", "sparkles", `<b>Resumen IA:</b> Entrega exitosa con 34% de inscripción a El Gran Viaje (promedio nacional 29%).`],
      ].map(([t, ic, x], i) => `<div class="flag flag--${t}" style="animation-delay:${i * 120}ms"><i data-lucide="${ic}"></i><span>${x}</span></div>`).join("")
        + (userImg ? `<div class="flag flag--info"><i data-lucide="info"></i><span>Demo: la extracción de tu foto es simulada. En producción se usaría un modelo de visión/OCR en el servidor.</span></div>` : "");
      icons(); busy = false;
      toast("Reporte extraído y validado — listo para consolidar", "file-check-2");
    }
    $("#runOcr").addEventListener("click", run);
    $("#ocrFile").addEventListener("change", (e) => {
      const file = e.target.files[0]; if (!file) return;
      const url = URL.createObjectURL(file);
      let img = $("img.user-img", stage);
      if (!img) { img = document.createElement("img"); img.className = "user-img"; img.alt = "Evidencia subida"; stage.prepend(img); }
      img.src = url; userImg = true; $(".doc", stage).style.visibility = "hidden";
      run();
    });
  }

  /* ---------------- D · LOGÍSTICA ---------------- */
  function initLogistics() {
    // conteo por visión
    const conv = $("#conveyor");
    let count = 0;
    setInterval(() => {
      if (!isDemoOn("logi")) return;
      const b = document.createElement("div");
      const tag = "CL-" + (Math.random() * 1e5 | 0).toString().padStart(5, "0");
      b.className = "cbox" + (Math.random() < .35 ? " green" : "");
      b.dataset.tag = tag;
      b.style.transform = `scale(${.85 + Math.random() * .25})`;
      conv.appendChild(b);
      // momento exacto en que el centro de la caja cruza la línea del sensor (60%)
      const W = conv.offsetWidth, tCross = 5000 * (0.6 * W + 80 - 31) / (W + 100);
      setTimeout(() => {
        const conf = (95 + Math.random() * 4.8).toFixed(1);
        b.classList.add("det"); b.innerHTML = `<b>caja ${conf}%</b>`;
        count++; $("#cvCount").textContent = fmt(count); $("#cvTag").textContent = tag; $("#cvConf").textContent = conf + "%";
      }, tCross);
      setTimeout(() => b.remove(), 5200);
    }, 1300);

    // rutas
    const svg = $("#routes");
    const CITIES = ["Iglesia A", "Iglesia B", "Iglesia C", "Iglesia D", "Iglesia E", "Iglesia F", "Iglesia G", "Iglesia H", "Iglesia I"];
    const d = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
    const len = (pts, ord) => ord.reduce((s, _, i) => s + d(pts[ord[i]], pts[ord[(i + 1) % ord.length]]), 0);
    function solve(pts) {
      // vecino más cercano + 2-opt (lo que OR-Tools hace mejor a escala)
      const left = new Set(pts.map((_, i) => i).slice(1)); const ord = [0];
      while (left.size) { const last = pts[ord.at(-1)]; let best = null; left.forEach((i) => { if (best === null || d(last, pts[i]) < d(last, pts[best])) best = i; }); ord.push(best); left.delete(best); }
      let improved = true;
      while (improved) {
        improved = false;
        for (let i = 1; i < ord.length - 1; i++) for (let k = i + 1; k < ord.length; k++) {
          const nw = [...ord.slice(0, i), ...ord.slice(i, k + 1).reverse(), ...ord.slice(k + 1)];
          if (len(pts, nw) < len(pts, ord) - .01) { ord.splice(0, ord.length, ...nw); improved = true; }
        }
      }
      return ord;
    }
    function draw() {
      const pts = [{ x: 200, y: 150, n: "Bodega" }, ...CITIES.map((n) => ({ x: 30 + Math.random() * 340, y: 25 + Math.random() * 250, n }))];
      const naive = pts.map((_, i) => i), opt = solve(pts);
      const path = (o) => "M" + o.map((i) => `${pts[i].x.toFixed(1)},${pts[i].y.toFixed(1)}`).join("L") + "Z";
      svg.innerHTML = `<path class="naive" d="${path(naive)}"/><path class="opt" id="optPath" d="${path(opt)}"/>` +
        pts.map((p, i) => i ? `<circle class="node" cx="${p.x}" cy="${p.y}" r="6"/><text x="${p.x + 9}" y="${p.y + 3}">${p.n.replace("Iglesia ", "")}</text>`
          : `<circle class="depot" cx="${p.x}" cy="${p.y}" r="10"/><text x="${p.x + 13}" y="${p.y + 4}" font-weight="700">Bodega</text>`).join("");
      const op = $("#optPath"), L = op.getTotalLength();
      op.style.strokeDasharray = L; op.style.strokeDashoffset = L;
      op.getBoundingClientRect();
      op.style.transition = "stroke-dashoffset 1.6s cubic-bezier(.2,.8,.2,1)"; op.style.strokeDashoffset = 0;
      const k = 1.9, a = len(pts, naive) * k, b = len(pts, opt) * k;
      animateCount($("#dNaive"), a, 0, "", 900); animateCount($("#dOpt"), b, 0, "", 1400);
      $("#dSave").textContent = `−${Math.round((1 - b / a) * 100)}% km`;
    }
    $("#reroute").addEventListener("click", draw);
    demoHooks.logi = () => draw();
    draw();

    // demanda
    $("#demand").innerHTML = REGIONS.map((r) => {
      const hist = [.78, .84, .9, .95, 1].map((f) => r.b * f * (0.96 + Math.random() * .08));
      const growth = r.d < 82 ? -2 + Math.random() * 4 : 3 + Math.random() * 6;
      const pred = r.b * (1 + growth / 100);
      const all = [...hist, pred], mx = Math.max(...all), mn = Math.min(...all);
      const sp = all.map((v, i) => `${(i / 5) * 100},${26 - ((v - mn) / (mx - mn || 1)) * 22}`).join(" L");
      return `<div class="dcell${r.d < 80 ? " alert" : ""}"><small>${r.s}</small><strong>${fmt(pred)}</strong><span class="delta ${growth >= 0 ? "up" : "dn"}">${growth >= 0 ? "+" : ""}${growth.toFixed(1)}%</span>
        <svg class="spark" viewBox="0 0 100 28" preserveAspectRatio="none"><path d="M${sp}"/></svg></div>`;
    }).join("");
  }

  /* ---------------- E · DASHBOARD ---------------- */
  function initDashboard() {
    const data = REGIONS.map((r) => ({ ...r }));
    let sort = "geo";
    const barsEl = $("#bars");
    barsEl.innerHTML = data.map((r) => `<div class="bar" data-i="${r.i}"><span class="bar__name" title="${r.n}">${r.s}</span><div class="bar__track"><div class="bar__fill"></div></div><span class="bar__val"></span></div>`).join("");
    const rowH = () => ($(".bar", barsEl)?.offsetHeight || 20) + 7;

    function render() {
      const order = [...data].sort((a, b) => (sort === "pct" ? b.d - a.d : a.i - b.i));
      barsEl.style.position = "relative";
      barsEl.style.height = order.length * rowH() + "px";
      order.forEach((r, pos) => {
        const el = $(`.bar[data-i="${r.i}"]`, barsEl);
        el.style.position = "absolute"; el.style.left = 0; el.style.right = 0; el.style.top = 0;
        el.style.transform = `translateY(${pos * rowH()}px)`;
        el.className = "bar" + (r.d < 80 ? " low" : r.d < 88 ? " mid" : "");
        $(".bar__fill", el).style.width = r.d + "%";
        $(".bar__val", el).textContent = fmt(r.d, 1) + "%";
      });
      const total = data.reduce((a, r) => a + r.b, 0);
      const dist = data.reduce((a, r) => a + r.b * r.d, 0) / total;
      $("#kDist").textContent = fmt(dist, 1) + "%";
      $("#ringDist").style.setProperty("--p", dist.toFixed(1));
      $("#kTotal").textContent = fmt(total);
      const low = data.filter((r) => r.d < 80);
      $("#kAlerts").textContent = low.length;
      $("#alerts").innerHTML = (low.length ? low.map((r) => `<li><i data-lucide="triangle-alert"></i><div><strong>${r.n}: ${fmt(r.d, 1)}%</strong>${fmt(Math.round(r.b * (1 - r.d / 100)))} cajas sin distribuir · equipo notificado</div></li>`).join("")
        : `<li class="ok"><i data-lucide="party-popper"></i><div><strong>¡Todas las regiones sobre 80%!</strong>Meta de cumplimiento alcanzada.</div></li>`)
        + `<li class="ok"><i data-lucide="trending-up"></i><div><strong>Metropolitana lidera</strong>${fmt(data[6].d, 1)}% distribuido</div></li>`;
      icons();
      return { dist, low, total };
    }
    $("#sortSeg").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      $$("#sortSeg button").forEach((x) => x.classList.toggle("is-on", x === b)); sort = b.dataset.s; render();
    });

    // tiempo real: llegan reportes nuevos
    setInterval(() => {
      if (!isDemoOn("dash")) return;
      const r = data[(Math.random() * data.length) | 0];
      if (r.d < 99) r.d = Math.min(99.4, r.d + Math.random() * .9);
      render();
    }, 2500);

    async function summary() {
      const s = render(), el = $("#summary");
      const sorted = [...data].sort((a, b) => b.d - a.d);
      const txt = `Resumen ejecutivo (generado por IA · ${new Date().toLocaleDateString("es-CL")}): A nivel nacional se han distribuido el ${fmt(s.dist, 1)}% de ${fmt(s.total)} cajas. `
        + `Las regiones con mejor desempeño son ${sorted[0].s} (${fmt(sorted[0].d, 1)}%) y ${sorted[1].s} (${fmt(sorted[1].d, 1)}%). `
        + (s.low.length ? `Requieren apoyo inmediato: ${s.low.map((r) => `${r.s} (${fmt(r.d, 1)}%)`).join(", ")}; se recomienda reasignar voluntarios de logística y revisar rutas de entrega. ` : "Ninguna región está bajo el umbral de 80%. ")
        + `Con la tendencia actual, la proyección indica 43 contenedores para 2027, superando la meta de 42.`;
      el.innerHTML = ""; const span = document.createElement("span"); const caret = document.createElement("span"); caret.className = "caret";
      el.append(span, caret);
      for (const w of txt.split(" ")) { span.textContent += w + " "; await sleep(28); }
      caret.remove();
    }
    $("#regen").addEventListener("click", summary);

    // forecast
    const years = [2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027];
    const real = [18, 22, 26, 29, 33, 36, 38];
    const pred = 43, goal = 42;
    $("#kCont").textContent = `${real.at(-1)} → ${goal}`;
    $("#kContEta").textContent = `Predicción 2027: ${pred} ✓`;
    $("#kContEta").className = "up";
    const W = 800, H = 220, pl = 40, pr = 20, pt = 16, pb = 30;
    const x = (i) => pl + (i / (years.length - 1)) * (W - pl - pr);
    const y = (v) => pt + (1 - (v - 10) / 40) * (H - pt - pb);
    const svg = $("#forecast");
    let g = "";
    [10, 20, 30, 40, 50].forEach((v) => (g += `<line class="grid" x1="${pl}" x2="${W - pr}" y1="${y(v)}" y2="${y(v)}"/><text x="6" y="${y(v) + 4}">${v}</text>`));
    years.forEach((yr, i) => (g += `<text x="${x(i) - 15}" y="${H - 8}">${yr}</text>`));
    const rp = real.map((v, i) => `${x(i)},${y(v)}`).join(" L");
    const li = real.length - 1;
    g += `<path class="band" d="M${x(li)},${y(real[li])} L${x(li + 1)},${y(pred + 3)} L${x(li + 1)},${y(pred - 3)} Z"/>`;
    g += `<line class="goal" x1="${pl}" x2="${W - pr}" y1="${y(goal)}" y2="${y(goal)}"/><text x="${W - pr - 90}" y="${y(goal) - 6}" style="fill:#d49112;font-weight:700">Meta 42</text>`;
    g += `<path class="real draw" style="--len:900" d="M${rp}"/>`;
    g += `<path class="pred" d="M${x(li)},${y(real[li])} L${x(li + 1)},${y(pred)}"/>`;
    g += real.map((v, i) => `<circle cx="${x(i)}" cy="${y(v)}" r="4" fill="var(--red)"><title>${years[i]}: ${v} contenedores</title></circle>`).join("");
    g += `<circle cx="${x(li + 1)}" cy="${y(pred)}" r="6" fill="var(--pine-2)"><title>Predicción 2027: ${pred}</title></circle><text x="${x(li + 1) - 70}" y="${y(pred) - 10}" style="fill:var(--pine-2);font-weight:700">Pred. ${pred}</text>`;
    svg.innerHTML = g;

    let first = true;
    demoHooks.dash = () => { render(); if (first) { first = false; summary(); } };
    render();
  }

  /* ---------------- H · CHAT RAG ---------------- */
  const KB = [
    { cat: "Iglesias", route: "Equipo regional", kw: ["iglesia", "postular", "participar", "ser parte", "inscribir", "ministerio", "church", "join", "igreja"],
      src: ["Manual de Iglesias Participantes §2", "Página ¿Quieres ser parte?"],
      a: { es: "¡Qué alegría! Tu iglesia puede postular con el formulario inteligente (Módulo A): necesitas nombre de la iglesia, contacto, dirección postal y de distribución, cantidad de niños por rango etario, email y celular. Te asignamos automáticamente a tu equipo regional y recibes los próximos pasos en minutos.",
        en: "Wonderful! Your church can apply through the smart form: church name, contact person, postal and distribution address, number of children by age range, email and phone. You'll be routed to your regional team and get next steps within minutes.",
        pt: "Que alegria! Sua igreja pode se inscrever pelo formulário inteligente: nome da igreja, contato, endereço postal e de distribuição, número de crianças por faixa etária, e-mail e celular. Você será direcionado à equipe regional." } },
    { cat: "Armado de cajas", route: "Resuelto por IA", kw: ["caja", "armar", "poner", "regalo", "que va", "prohibido", "llevar", "box", "pack", "caixa", "contenido", "articulos"],
      src: ["Guía de armado de cajas", "FAQ #4"],
      a: { es: "Elige si es para niño o niña y un rango (2–4, 5–9 o 10–14). Incluye un artículo especial (peluche, pelota, muñeca), útiles escolares, artículos de higiene y un toque personal como una carta o foto. No incluyas alimentos, líquidos, medicamentos, artículos usados ni objetos bélicos.",
        en: "Pick boy or girl and an age range (2–4, 5–9, 10–14). Include a 'wow' item (stuffed toy, ball, doll), school supplies, hygiene items and a personal note or photo. Don't include food, liquids, medicine, used items or war-related toys.",
        pt: "Escolha menino ou menina e a faixa etária (2–4, 5–9, 10–14). Inclua um item especial (pelúcia, bola, boneca), material escolar, itens de higiene e um bilhete pessoal. Não inclua alimentos, líquidos, remédios, itens usados ou brinquedos de guerra." } },
    { cat: "Reportes", route: "Resuelto por IA", kw: ["reporte", "informe", "distribucion", "post", "planilla", "formulario", "evidencia", "foto", "report"],
      src: ["Instructivo Reporte Post-Distribución", "Módulo C"],
      a: { es: "El reporte post-distribución ahora es un formulario nativo de 3 pasos. Puedes sacar una foto a tu planilla de asistencia y la IA extrae niños asistentes, cajas entregadas y fecha; si detecta inconsistencias (por ejemplo, más cajas que niños), te pedirá confirmar antes de enviar.",
        en: "The post-distribution report is now a 3-step native form. Snap a photo of your attendance sheet and AI extracts attendees, boxes delivered and date; it flags inconsistencies before you submit.",
        pt: "O relatório pós-distribuição agora é um formulário nativo de 3 etapas. Fotografe a lista de presença e a IA extrai os dados e aponta inconsistências antes do envio." } },
    { cat: "Discipulado", route: "Equipo de capacitación", kw: ["gran viaje", "discipulado", "maestro", "lecciones", "curso", "clases", "journey", "teacher"],
      src: ["Guía del Maestro – El Gran Viaje", "Reporte del Maestro"],
      a: { es: "El Gran Viaje es el programa de discipulado para niños que reciben una caja. Los maestros se capacitan (ahora también online con quiz) y completan el Reporte del Maestro desde el celular al terminar cada ciclo.",
        en: "The Greatest Journey is the discipleship program for children who receive a box. Teachers get trained (now also online with quizzes) and submit the Teacher Report from their phone.",
        pt: "A Maior Jornada é o programa de discipulado para as crianças que recebem uma caixa. Professores são capacitados (também online) e enviam o relatório pelo celular." } },
    { cat: "Voluntariado", route: "Coordinación de voluntarios", kw: ["voluntario", "voluntariado", "ayudar", "servir", "rol", "equipo", "volunteer", "help"],
      src: ["Manual del Voluntario", "Roles de equipos regionales"],
      a: { es: "Hay 6 roles en cada equipo regional: coordinación, relación con iglesias, logística, comunicaciones, capacitación y datos. Cuéntame tus habilidades y región y te recomiendo el rol ideal; luego recibes un checklist de onboarding personalizado.",
        en: "Each regional team has 6 roles: coordination, church relations, logistics, communications, training and data. Tell me your skills and region and I'll recommend the best fit plus a personalized onboarding checklist.",
        pt: "Cada equipe regional tem 6 funções: coordenação, igrejas, logística, comunicação, capacitação e dados. Conte suas habilidades e região e eu recomendo a função ideal." } },
    { cat: "Donaciones", route: "Equipo de donaciones", kw: ["donar", "donacion", "dinero", "envio", "costo", "aporte", "pagar", "donate", "doar"],
      src: ["FAQ Donaciones", "Política de transparencia"],
      a: { es: "Puedes apoyar armando cajas o con un aporte para el envío y el programa de discipulado. Para detalles de cuentas y certificados, te derivo al equipo de donaciones, que te responderá por email.",
        en: "You can help by packing boxes or giving toward shipping and discipleship. For account details and receipts I'll route you to our donations team.",
        pt: "Você pode ajudar montando caixas ou contribuindo com o envio e o discipulado. Para detalhes, encaminho você à equipe de doações." } },
    { cat: "Prensa", route: "Comunicaciones", kw: ["prensa", "medio", "entrevista", "periodista", "noticia", "press", "media"],
      src: ["Kit de prensa"],
      a: { es: "Para entrevistas o material de prensa, te conecto con el equipo de comunicaciones. Mientras tanto, puedes descargar el kit de prensa con cifras e imágenes aprobadas.",
        en: "For interviews or press material, I'll connect you with our communications team. Meanwhile you can download the press kit.",
        pt: "Para entrevistas ou material de imprensa, conecto você à equipe de comunicação." } },
  ];
  const UI = {
    es: { hi: "¡Hola! 👋 Soy el asistente de OCC Chile. Respondo con información de manuales y FAQs oficiales. ¿En qué te ayudo?", miss: "No encontré eso en los documentos. Derivé tu consulta a una persona del equipo, que te responderá pronto. 🙏", chips: ["¿Cómo postula mi iglesia?", "¿Qué pongo en una caja?", "¿Cómo hago el reporte?", "Quiero ser voluntario", "¿Qué es El Gran Viaje?"] },
    en: { hi: "Hi! 👋 I'm the OCC Chile assistant. I answer from official manuals and FAQs. How can I help?", miss: "I couldn't find that in our documents. I've routed your question to a team member. 🙏", chips: ["How can my church join?", "What goes in a box?", "How do I report?", "I want to volunteer"] },
    pt: { hi: "Olá! 👋 Sou o assistente da OCC Chile. Respondo com base nos manuais e FAQs oficiais. Como posso ajudar?", miss: "Não encontrei isso nos documentos. Encaminhei sua pergunta para a equipe. 🙏", chips: ["Como minha igreja participa?", "O que vai na caixa?", "Quero ser voluntário"] },
  };
  function initChat() {
    const body = $("#chatBody"), form = $("#chatForm"), input = $("#chatIn"), langSel = $("#lang");
    let lang = "es", busy = false;
    const add = (html, who) => {
      const m = document.createElement("div"); m.className = "msg msg--" + who; m.innerHTML = html; body.appendChild(m);
      body.scrollTop = body.scrollHeight; icons(); return m;
    };
    const chips = () => { $("#chatChips").innerHTML = UI[lang].chips.map((c) => `<button type="button">${c}</button>`).join(""); };
    const steps = $$("#ragSteps li");
    const setStep = (i, txt) => { steps[i].classList.add("on"); steps[i].querySelector("span").textContent = txt; };
    async function ask(q) {
      if (busy || !q.trim()) return; busy = true;
      add(q.replace(/</g, "&lt;"), "user");
      steps.forEach((s) => { s.classList.remove("on"); s.querySelector("span").textContent = "—"; });
      const t = add(`<span class="typing"><i></i><i></i><i></i></span>`, "bot");
      const nq = norm(q);
      const scored = KB.map((k) => ({ k, s: k.kw.reduce((a, w) => a + (nq.includes(norm(w)) ? w.length : 0), 0) })).sort((a, b) => b.s - a.s);
      const hit = scored[0].s > 0 ? scored[0].k : null;
      await sleep(350); setStep(0, hit ? `${hit.cat} · confianza ${(.82 + Math.random() * .15).toFixed(2)}` : "Sin categoría clara");
      await sleep(450); setStep(1, hit ? `${hit.src.length} fragmentos · top-k=4` : "0 fragmentos relevantes");
      await sleep(450); setStep(2, hit ? `Respuesta con ${hit.src.length} citas · ${lang.toUpperCase()}` : "Se evita inventar respuesta");
      await sleep(250); setStep(3, hit ? hit.route : "Humano · bandeja de atención");
      t.remove();
      if (hit) add(`${hit.a[lang]}<div class="src">${hit.src.map((s) => `<span><i data-lucide="file-text" style="width:12px;height:12px"></i>${s}</span>`).join("")}</div>`, "bot");
      else add(UI[lang].miss, "bot");
      busy = false;
    }
    form.addEventListener("submit", (e) => { e.preventDefault(); const q = input.value; input.value = ""; ask(q); });
    $("#chatChips").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) ask(b.textContent); });
    langSel.addEventListener("change", () => { lang = langSel.value; chips(); add(UI[lang].hi, "bot"); toast("Idioma cambiado · traducción con IA", "languages"); });
    add(UI.es.hi, "bot"); chips();

    const topics = [["Armado de cajas", 34], ["Fechas de recolección", 26], ["Postulación de iglesias", 18], ["Reportes", 12], ["Voluntariado", 10]];
    $("#topics").innerHTML = topics.map(([n, v]) => `<div class="topic"><span>${n}</span><b>${v}%</b><i style="--w:${v * 2.5}%"></i></div>`).join("");
  }

  /* ---------------- ARQUITECTURA ---------------- */
  function initArch() {
    const mods = [["A", "Iglesias", "church"], ["B", "Voluntarios", "users"], ["C", "Reportes", "clipboard-check"], ["D", "Logística", "truck"],
      ["E", "Métricas", "layout-dashboard"], ["F", "Capacitación", "graduation-cap"], ["G", "Comunicación", "megaphone"], ["H", "Soporte", "life-buoy"]];
    $("#archMods").innerHTML = mods.map(([k, n, ic]) => `<span><i data-lucide="${ic}"></i><b>${k}</b> ${n}</span>`).join("");
  }

  /* ---------------- BOOT ---------------- */
  document.addEventListener("DOMContentLoaded", () => {
    initProcesses();
    initFlows();
    initArch();
    initTheme();
    initNav();
    initReveal();
    initCounters();
    initHero();
    initDemoTabs();
    initForm();
    initVolunteers();
    initOCR();
    initLogistics();
    initDashboard();
    initChat();
    icons();
  });
})();
